import React from 'react';
import Footer from './componentspf/footer';
import Body from './componentspf/body.js';
import Header1 from './componentspf/header1';


export default function ProfileViewer() {
    return (
     <div>
            <Header1 />
           <Body />
            <Footer />
        </div>
    )
}
