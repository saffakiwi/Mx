import React from 'react';
import { Card } from '@material-ui/core';
import { CardActions } from '@material-ui/core';
import { CardContent } from '@material-ui/core';
import { makeStyles } from '@material-ui/core';
import { Grid } from '@material-ui/core';


const useStyles = makeStyles({
    root: {
        borderRadius: "25px",
        marginTop: "40px",
        marginRight: "180px",
        elevation: "0",
        marginBottom:"40px"
    },
    left: {
        padding: '7px',
        display: "block",
        margin: "auto",
    },
    h1: {
        fontFamily: "Nunito",
        fontSize: "45px",
        fontWeight: "bold",
        color: "#707070",
        marginLeft: "80px",
        marginTop: "30px",
    },
    list: {
        marginLeft:"13px",
        marginBottom:"50px",
        spacing:"20px",
        marginRight: '0',
    },
    a:{
        fontFamily: "Nunito",
        fontSize: "20px",
        fontWeight: "bold",
        color: "#a5a5a5",
        padding: "12px",
     },
     b:{
        fontFamily: "Open Sans",
        fontSize: "20px",
        color: "#707070",
        padding: "12px",
        marginRight: "0",
     }
});


export default function CardR() {
    const classes = useStyles();
    return (
        <>
        <Card variant="outlined" className={classes.root} >
            <CardContent className={classes.left}>
                <h1 className={classes.h1}> Jasmina Salvador</h1>
                    <Grid className={classes.list} container spacing={6} >
                        <Grid item xs={5}className={classes.a}>
                            <p>School</p>
                            <p>Courses Purchased</p>
                            <p>Date of Birth</p>
                            <p>Contact No</p>
                            <p>Email Address</p> </Grid>                         
                        <Grid item sm={6} className={classes.b}>
                        <p>Homai School</p>
                        <p>Beginner</p>
                        <p>25 June 1986</p>
                        <p>027 754 28 00</p>
                        <p>jsalvador@homai.edu</p></Grid>
                    </Grid>
            
            </CardContent>
            <CardActions>
            </CardActions>
        </Card>
        </>
    );
}

// You will need to create a usestyles for the root - you will then be able to make changes to the sizing. Something like:
// name: {
// width: "xx",
// height: "xx",
// },

// then in your element:
// classes={{root: styles.name}}

