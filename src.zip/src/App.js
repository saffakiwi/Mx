import React from 'react';
import './App.css';
import ProfileViewer from './profileViewer.js';


function App() {
  return (
    <div className="App">
      <ProfileViewer />
      </div>
  );
}

export default App;
