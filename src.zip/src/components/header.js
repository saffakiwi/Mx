import React from 'react';
import { AppBar } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import { Grid } from '@material-ui/core';
import Logo from './StarLogo.png';
import Maori from './Maori.png';
import Nz from './Nz.png';
import Lang from './Lang.png';
import User from './UserCircle.png';
import RegLogin from './RegLogin.png';
import './header.css';


export default function Header() {
  return (
    <div>
      <AppBar maxWidth={"lg"}  style={{ backgroundColor: '#43C0F6', height:"40px"}}>
          <Grid container spacing={8}>
            <Grid className="logo" item xs>
              <img src={Logo} className="logoPic" /></Grid>
            <Grid item xs style={{ fontSize:'2px', fontFamily:'Open Sans'}} className="middleButtons">
              <Button color="inherit" position="static" style={{fontSize:"8px"}}>HOME</Button>
              <Button color="inherit"  style={{ fontSize:"8px"}}> FEATURES</Button>
              <Button color="inherit"  style={{ fontSize:"8px"}}> TEACHERS</Button> </Grid>
            <Grid item xs style={{alignItem:"flex-end"}} >
            {" "} {" "} <img src={Lang} style={{ height: "10px",  width: "15px" }}  />  {" "}
              <img src={Nz}  /> {" "}
               <img src={Maori} /> <br />
              <img src={User} style={{ height: "15px",  width: "15px" }}/>
              <Button color="inherit"><img src={RegLogin} alignItem='flex-end' style={{ height:"15px", width:"100px"}} /> </Button></Grid>
          </Grid>
      </AppBar>
    </div>
  )
};
